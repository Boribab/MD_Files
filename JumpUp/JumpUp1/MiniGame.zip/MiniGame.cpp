#include <iostream>
#include <string>
#include "Chest.h"
#include "Enemy.h"
#include "Fountain.h"
#include "Room.h"
#include "Player.h"
#include "Game.h"
#include "enum.h"
#include <stdlib.h>
#include <vector>

using namespace std;

int main() {
	Game g;
}