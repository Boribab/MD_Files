#include <vector>
#include "Room.h"

class Game {
	vector<Room*> room;
	vector<Room*> r;
public:
	Game();
};