#include <iostream>
#include <string>
using namespace std;

enum class Where {
	West,
	East,
	South,
	North
};