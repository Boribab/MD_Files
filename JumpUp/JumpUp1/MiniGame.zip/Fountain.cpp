#include "Fountain.h"

void Fountain::fountain() {
	is = true;
}
bool Fountain::IsFountain() {
	return is;
}