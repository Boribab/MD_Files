#include <vector>
#include "Room.hpp"

class Game {
	vector<Room*> room;
	vector<Room*> r;
public:
	Game();
	~Game();
};
