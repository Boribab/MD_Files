#pragma once
#include <iostream>
#include <string>
using namespace std;

class Fountain {
	bool is = false;
public:
	void fountain();
	bool IsFountain();
};