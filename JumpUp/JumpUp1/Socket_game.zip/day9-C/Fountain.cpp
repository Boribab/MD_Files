#include "Fountain.hpp"

void Fountain::fountain() {
	is = true;
}
bool Fountain::IsFountain() {
	return is;
}